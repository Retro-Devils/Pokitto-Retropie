#include "types.hpp"

namespace AUDIO {
    void write(u8 data){}
}

namespace PEX {
    bool init(u32 port){ return true; }
    u32 update(){}
}
