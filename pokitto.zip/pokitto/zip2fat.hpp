bool convertFile(const std::string& fileName);
