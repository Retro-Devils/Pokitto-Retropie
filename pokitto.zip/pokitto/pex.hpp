#pragma once

namespace PEX {
    bool init( u32 port );
    
    u32 update();
}
