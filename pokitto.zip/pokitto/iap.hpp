namespace IAP {
    extern void (*command[])(u32,u32,u32,u32);
    void stub(u32,u32,u32,u32);
}
