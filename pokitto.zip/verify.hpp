namespace VERIFY {
    void init();
    void update();
}
