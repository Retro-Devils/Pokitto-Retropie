#pragma once

namespace PROF {
    extern u32 hits[];
    extern bool dumpOnExit;
    void init( bool );
}
