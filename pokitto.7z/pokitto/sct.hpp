namespace SCT {
    
    void init();

    extern MMU::Layout sct0Layout, sct1Layout;
    
}
