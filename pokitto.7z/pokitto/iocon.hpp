#pragma once

#include "mmu.hpp"

namespace IOCON {

    void init();

    extern MMU::Layout layout;


}
